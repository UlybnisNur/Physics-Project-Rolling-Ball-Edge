import { useEffect, useMemo, useRef, useState } from "react";
import { ControlsPanel } from "./components/ControlsPanel";
import { GraphPanel } from "./components/GraphPanel";
import { ModelComparison } from "./components/ModelComparison";
import { ReportHelper } from "./components/ReportHelper";
import { SimulationCanvas } from "./components/SimulationCanvas";
import { TheoryPanel } from "./components/TheoryPanel";
import { DEFAULT_PARAMS, sampleAt, simulate, type SimulationParams } from "./utils/physics";

export default function App() {
  const [params, setParams] = useState<SimulationParams>(DEFAULT_PARAMS);
  const [playing, setPlaying] = useState(true);
  const [time, setTime] = useState(0);
  const lastFrameRef = useRef<number | null>(null);
  const result = useMemo(() => simulate(params), [params]);
  const current = useMemo(() => sampleAt(result.samples, time), [result.samples, time]);

  useEffect(() => {
    setTime((previous) => Math.min(previous, result.duration));
  }, [result.duration]);

  useEffect(() => {
    if (!playing) {
      lastFrameRef.current = null;
      return;
    }

    let frameId = 0;
    const tick = (now: number) => {
      if (lastFrameRef.current === null) {
        lastFrameRef.current = now;
      }
      const deltaSeconds = (now - lastFrameRef.current) / 1000;
      lastFrameRef.current = now;

      setTime((previous) => {
        const next = previous + deltaSeconds * params.speed;
        if (next >= result.duration) {
          setPlaying(false);
          return result.duration;
        }
        return next;
      });

      frameId = requestAnimationFrame(tick);
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [params.speed, playing, result.duration]);

  const updateParams = (next: SimulationParams) => {
    setParams(next);
    setTime(0);
    setPlaying(true);
  };

  const resetAnimation = () => {
    setTime(0);
    setPlaying(true);
  };

  return (
    <main className="app-shell">
      <div className="workspace-grid">
        <div className="left-column">
          <SimulationCanvas
            result={result}
            current={current}
            playing={playing}
            onTogglePlaying={() => setPlaying((value) => !value)}
            onResetAnimation={resetAnimation}
          />

          <section className="timeline-panel" aria-label="Animation timeline">
            <label>
              <span>Time</span>
              <input
                type="range"
                min={0}
                max={result.duration}
                step={0.001}
                value={time}
                onChange={(event) => {
                  setTime(Number(event.target.value));
                  setPlaying(false);
                }}
              />
              <output>{time.toFixed(2)} s</output>
            </label>
          </section>
        </div>

        <aside className="right-column">
          <ControlsPanel
            params={params}
            playing={playing}
            onChange={updateParams}
            onTogglePlaying={() => setPlaying((value) => !value)}
            onResetAnimation={resetAnimation}
          />
          <ModelComparison result={result} current={current} />
        </aside>
      </div>

      <GraphPanel result={result} />
      <TheoryPanel />
      <ReportHelper params={params} result={result} />
    </main>
  );
}
