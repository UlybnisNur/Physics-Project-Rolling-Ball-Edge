import { Pause, Play, RotateCcw } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { SimulationParams, SimulationResult, SimulationSample } from "../utils/physics";

interface SimulationCanvasProps {
  result: SimulationResult;
  current: SimulationSample;
  playing: boolean;
  onTogglePlaying: () => void;
  onResetAnimation: () => void;
}

interface Point {
  x: number;
  y: number;
}

export function SimulationCanvas({
  result,
  current,
  playing,
  onTogglePlaying,
  onResetAnimation,
}: SimulationCanvasProps) {
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [size, setSize] = useState({ width: 900, height: 480 });

  useEffect(() => {
    if (!wrapperRef.current) return;
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      setSize({
        width: Math.max(360, entry.contentRect.width),
        height: Math.max(360, entry.contentRect.height),
      });
    });
    observer.observe(wrapperRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(size.width * dpr);
    canvas.height = Math.floor(size.height * dpr);
    canvas.style.width = `${size.width}px`;
    canvas.style.height = `${size.height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    drawScene(ctx, size.width, size.height, result, current);
  }, [current, result, size]);

  return (
    <section className="simulation-stage" aria-label="Rolling ball simulation">
      <div className="canvas-toolbar">
        <div>
          <p className="eyebrow">Bacon 2005</p>
          <h1>How balls roll off tables</h1>
        </div>
        <div className="playback-row">
          <button className="icon-button primary" type="button" onClick={onTogglePlaying} aria-label={playing ? "Pause" : "Play"}>
            {playing ? <Pause size={18} /> : <Play size={18} />}
          </button>
          <button className="icon-button" type="button" onClick={onResetAnimation} aria-label="Restart animation">
            <RotateCcw size={18} />
          </button>
        </div>
      </div>
      <div className="canvas-wrap" ref={wrapperRef}>
        <canvas ref={canvasRef} />
      </div>
      <div className="phase-strip">
        {(["rolling", "no-slip", "slipping", "projectile"] as const).map((phase) => (
          <span key={phase} className={current.phase === phase ? "active" : ""}>
            {phase}
          </span>
        ))}
      </div>
    </section>
  );
}

function drawScene(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  result: SimulationResult,
  current: SimulationSample,
) {
  const params = result.params;
  ctx.clearRect(0, 0, width, height);

  const v = params.radius * params.omegaI;
  const xMin = Math.min(-0.55, -v * result.edgeTime - 0.18);
  const landingMax = Math.max(result.full.landingDistance, result.simple.landingDistance, result.noSlipOnly.landingDistance);
  const xMax = Math.max(0.8, landingMax + 0.2);
  const yMin = 0;
  const yMax = params.tableHeight + Math.max(0.34, params.radius * 7);
  const margin = { left: 40, right: 30, top: 34, bottom: 44 };
  const scale = Math.min(
    (width - margin.left - margin.right) / (xMax - xMin),
    (height - margin.top - margin.bottom) / (yMax - yMin),
  );
  const plotWidth = (xMax - xMin) * scale;
  const plotHeight = (yMax - yMin) * scale;
  const offsetX = margin.left + Math.max(0, (width - margin.left - margin.right - plotWidth) / 2);
  const offsetY = margin.top + Math.max(0, (height - margin.top - margin.bottom - plotHeight) / 2);
  const toCanvas = (point: Point): Point => ({
    x: offsetX + (point.x - xMin) * scale,
    y: offsetY + (yMax - point.y) * scale,
  });

  drawBackground(ctx, width, height);
  drawFloor(ctx, toCanvas, xMin, xMax);
  drawTable(ctx, toCanvas, xMin, params.tableHeight);
  drawRamp(ctx, toCanvas, xMin, params.tableHeight);
  drawTrajectory(ctx, toCanvas, result);
  drawSimpleProjectile(ctx, toCanvas, result);
  drawEdgeGeometry(ctx, toCanvas, params.tableHeight, params.radius);
  drawBall(ctx, toCanvas, current, params.radius, scale);
  drawVectors(ctx, toCanvas, current, params);
  drawLandingMarkers(ctx, toCanvas, result);
  drawHud(ctx, width, current);
}

function drawBackground(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, "#f8fbff");
  gradient.addColorStop(1, "#eef5f0");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
}

function drawFloor(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, xMin: number, xMax: number) {
  const left = toCanvas({ x: xMin, y: 0 });
  const right = toCanvas({ x: xMax, y: 0 });
  ctx.strokeStyle = "#94a3b8";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(left.x, left.y);
  ctx.lineTo(right.x, right.y);
  ctx.stroke();
}

function drawTable(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, xMin: number, tableHeight: number) {
  const topLeft = toCanvas({ x: xMin, y: tableHeight });
  const edge = toCanvas({ x: 0, y: tableHeight });
  const bottom = toCanvas({ x: 0, y: tableHeight - 0.06 });
  ctx.fillStyle = "#475569";
  ctx.fillRect(topLeft.x, topLeft.y, edge.x - topLeft.x, Math.max(8, bottom.y - topLeft.y));
  ctx.fillStyle = "#334155";
  ctx.fillRect(edge.x - 5, topLeft.y, 10, Math.max(36, bottom.y - topLeft.y + 32));
  ctx.fillStyle = "#e2e8f0";
  ctx.fillRect(topLeft.x, topLeft.y - 6, edge.x - topLeft.x + 4, 6);
}

function drawRamp(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, xMin: number, tableHeight: number) {
  const a = toCanvas({ x: xMin + 0.03, y: tableHeight + 0.18 });
  const b = toCanvas({ x: Math.min(-0.2, xMin + 0.38), y: tableHeight + 0.02 });
  ctx.strokeStyle = "#64748b";
  ctx.lineWidth = 5;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
}

function drawTrajectory(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, result: SimulationResult) {
  const points = result.samples.filter((sample) => sample.phase !== "rolling");
  if (points.length < 2) return;
  ctx.strokeStyle = "#dc2626";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  points.forEach((sample, index) => {
    const p = toCanvas({ x: sample.x, y: sample.y });
    if (index === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  });
  ctx.stroke();
}

function drawSimpleProjectile(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, result: SimulationResult) {
  const params = result.params;
  const steps = 40;
  const flight = Math.sqrt((2 * params.tableHeight) / params.gravity);
  const vx = params.radius * params.omegaI;
  ctx.strokeStyle = "#64748b";
  ctx.lineWidth = 1.8;
  ctx.setLineDash([8, 7]);
  ctx.beginPath();
  for (let i = 0; i <= steps; i += 1) {
    const t = (flight * i) / steps;
    const p = toCanvas({
      x: vx * t,
      y: params.tableHeight + params.radius - 0.5 * params.gravity * t * t,
    });
    if (i === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);
}

function drawEdgeGeometry(
  ctx: CanvasRenderingContext2D,
  toCanvas: (point: Point) => Point,
  tableHeight: number,
  radius: number,
) {
  const edge = toCanvas({ x: 0, y: tableHeight });
  ctx.fillStyle = "#111827";
  ctx.beginPath();
  ctx.arc(edge.x, edge.y, 5, 0, Math.PI * 2);
  ctx.fill();

  const arcRadius = Math.max(14, radius * 4 * Math.abs(toCanvas({ x: radius, y: tableHeight }).x - edge.x) / Math.max(radius, 1e-6));
  ctx.strokeStyle = "rgba(17, 24, 39, 0.2)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(edge.x, edge.y, arcRadius, -Math.PI / 2, 0);
  ctx.stroke();
}

function drawBall(
  ctx: CanvasRenderingContext2D,
  toCanvas: (point: Point) => Point,
  current: SimulationSample,
  radius: number,
  scale: number,
) {
  const center = toCanvas({ x: current.x, y: current.y });
  const r = Math.max(9, radius * scale);
  const gradient = ctx.createRadialGradient(center.x - r * 0.35, center.y - r * 0.45, r * 0.15, center.x, center.y, r);
  gradient.addColorStop(0, "#f8fafc");
  gradient.addColorStop(0.45, "#94a3b8");
  gradient.addColorStop(1, "#334155");
  ctx.fillStyle = gradient;
  ctx.strokeStyle = "#0f172a";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(center.x, center.y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.save();
  ctx.translate(center.x, center.y);
  ctx.rotate(current.rotationAngle);
  ctx.strokeStyle = "#f8fafc";
  ctx.lineWidth = Math.max(2, r * 0.12);
  ctx.beginPath();
  ctx.moveTo(-r * 0.72, 0);
  ctx.lineTo(r * 0.72, 0);
  ctx.stroke();
  ctx.restore();
}

function drawVectors(
  ctx: CanvasRenderingContext2D,
  toCanvas: (point: Point) => Point,
  current: SimulationSample,
  params: SimulationParams,
) {
  if (current.phase !== "no-slip" && current.phase !== "slipping") {
    if (current.phase === "projectile") {
      drawArrow(ctx, toCanvas({ x: current.x, y: current.y }), toCanvas({ x: current.x + current.vx * 0.16, y: current.y + current.vy * 0.035 }), "#2563eb", "v");
    }
    return;
  }

  const start = toCanvas({ x: current.x, y: current.y });
  const edge = toCanvas({ x: 0, y: params.tableHeight });
  ctx.strokeStyle = "rgba(15, 23, 42, 0.24)";
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.moveTo(edge.x, edge.y);
  ctx.lineTo(start.x, start.y);
  ctx.stroke();
  ctx.setLineDash([]);

  const q = current.q;
  const normalScale = 0.08 * Math.min(1.6, current.normalPerMass / Math.max(0.1, params.gravity));
  const frictionScale = 0.08 * Math.min(1.6, current.frictionPerMass / Math.max(0.1, params.gravity));
  drawArrow(
    ctx,
    start,
    toCanvas({ x: current.x + Math.sin(q) * normalScale, y: current.y + Math.cos(q) * normalScale }),
    "#16a34a",
    "F_N",
  );
  drawArrow(
    ctx,
    start,
    toCanvas({ x: current.x + Math.cos(q) * frictionScale, y: current.y - Math.sin(q) * frictionScale }),
    "#ea580c",
    "F_f",
  );
}

function drawLandingMarkers(ctx: CanvasRenderingContext2D, toCanvas: (point: Point) => Point, result: SimulationResult) {
  const y = 0;
  const markers = [
    { x: result.simple.landingDistance, label: "simple", color: "#64748b" },
    { x: result.noSlipOnly.landingDistance, label: "no-slip", color: "#7c3aed" },
    { x: result.full.landingDistance, label: "full", color: "#dc2626" },
  ];
  markers.forEach((marker, index) => {
    const p = toCanvas({ x: marker.x, y });
    ctx.strokeStyle = marker.color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - 10);
    ctx.lineTo(p.x, p.y + 10);
    ctx.stroke();
    ctx.fillStyle = marker.color;
    ctx.font = "12px Inter, system-ui, sans-serif";
    ctx.fillText(marker.label, p.x + 5, p.y - 12 - index * 15);
  });
}

function drawHud(ctx: CanvasRenderingContext2D, width: number, current: SimulationSample) {
  const pad = 14;
  const label = `phase: ${current.phase}`;
  ctx.font = "600 13px Inter, system-ui, sans-serif";
  const textWidth = ctx.measureText(label).width;
  ctx.fillStyle = "rgba(255,255,255,0.86)";
  ctx.strokeStyle = "rgba(15,23,42,0.12)";
  ctx.lineWidth = 1;
  roundRect(ctx, width - textWidth - pad * 2 - 18, 16, textWidth + pad * 2, 34, 8);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#0f172a";
  ctx.fillText(label, width - textWidth - pad - 18, 38);
}

function drawArrow(ctx: CanvasRenderingContext2D, from: Point, to: Point, color: string, label: string) {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.hypot(dx, dy);
  if (length < 4) return;

  const ux = dx / length;
  const uy = dy / length;
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(from.x, from.y);
  ctx.lineTo(to.x, to.y);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(to.x, to.y);
  ctx.lineTo(to.x - ux * 9 - uy * 4, to.y - uy * 9 + ux * 4);
  ctx.lineTo(to.x - ux * 9 + uy * 4, to.y - uy * 9 - ux * 4);
  ctx.closePath();
  ctx.fill();
  ctx.font = "600 12px Inter, system-ui, sans-serif";
  ctx.fillText(label, to.x + 6, to.y - 6);
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}
