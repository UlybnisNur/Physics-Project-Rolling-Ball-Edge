import { clamp, rk4Step } from "./integrator";

export type Phase = "rolling" | "no-slip" | "slipping" | "projectile";

export interface SimulationParams {
  omegaI: number;
  radius: number;
  muS: number;
  muK: number;
  tableHeight: number;
  gravity: number;
  speed: number;
}

export interface SimulationSample {
  t: number;
  phase: Phase;
  q: number;
  edgeAngle: number;
  angleRate: number;
  spinOmega: number;
  rotationAngle: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  normalPerMass: number;
  frictionPerMass: number;
  frictionRatio: number;
}

export interface ModelPrediction {
  label: string;
  landingDistance: number;
  finalOmega: number;
  liftTime: number;
  liftQ: number;
  liftX: number;
  liftY: number;
  liftVx: number;
  liftVy: number;
  phaseAtLift: Phase;
}

export interface SweepPoint {
  omega: number;
  simple: number;
  noSlip: number;
  full: number;
}

export interface SimulationResult {
  params: SimulationParams;
  samples: SimulationSample[];
  simple: ModelPrediction;
  noSlipOnly: ModelPrediction;
  full: ModelPrediction;
  sweep: SweepPoint[];
  duration: number;
  edgeTime: number;
  thresholdOmega: number;
  kickObserved: boolean;
}

const PRE_EDGE_TIME = 0.7;
const INTEGRATION_DT = 0.0006;
const SAMPLE_DT = 0.004;
const PROJECTILE_SAMPLE_DT = 0.012;
const MAX_CONTACT_TIME = 1.4;

export const DEFAULT_PARAMS: SimulationParams = {
  omegaI: 8.65,
  radius: 0.0125,
  muS: 0.35,
  muK: 0.22,
  tableHeight: 0.8,
  gravity: 9.81,
  speed: 1,
};

export function simulate(params: SimulationParams): SimulationResult {
  const sanitized = sanitizeParams(params);
  const simple = predictSimple(sanitized);
  const noSlipOnly = predictNoSlipOnly(sanitized);
  const contact = simulateFullContact(sanitized);
  const full = contact.prediction;
  const samples = buildSamples(sanitized, contact.contactSamples, full);
  const duration = samples.length > 0 ? samples[samples.length - 1].t : PRE_EDGE_TIME;
  const thresholdOmega = Math.sqrt(sanitized.gravity / sanitized.radius);
  const kickDelta = full.landingDistance - simple.landingDistance;
  const kickObserved = kickDelta > Math.max(0.03, simple.landingDistance * 0.045);

  return {
    params: sanitized,
    samples,
    simple,
    noSlipOnly,
    full,
    sweep: buildSweep(sanitized, thresholdOmega),
    duration,
    edgeTime: PRE_EDGE_TIME,
    thresholdOmega,
    kickObserved,
  };
}

export function sampleAt(samples: SimulationSample[], time: number): SimulationSample {
  if (samples.length === 0) {
    throw new Error("No simulation samples are available.");
  }

  if (time <= samples[0].t) return samples[0];
  if (time >= samples[samples.length - 1].t) return samples[samples.length - 1];

  let low = 0;
  let high = samples.length - 1;
  while (high - low > 1) {
    const mid = Math.floor((low + high) / 2);
    if (samples[mid].t <= time) {
      low = mid;
    } else {
      high = mid;
    }
  }

  const a = samples[low];
  const b = samples[high];
  const span = Math.max(1e-9, b.t - a.t);
  const f = clamp((time - a.t) / span, 0, 1);
  return interpolateSample(a, b, f);
}

export function formatNumber(value: number, decimals = 2): string {
  if (!Number.isFinite(value)) return "n/a";
  return value.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function sanitizeParams(params: SimulationParams): SimulationParams {
  return {
    omegaI: clamp(params.omegaI, 0, 90),
    radius: clamp(params.radius, 0.004, 0.08),
    muS: clamp(params.muS, 0, 2),
    muK: clamp(params.muK, 0, 2),
    tableHeight: clamp(params.tableHeight, 0.1, 2.2),
    gravity: clamp(params.gravity, 0.5, 25),
    speed: clamp(params.speed, 0.1, 6),
  };
}

function predictSimple(params: SimulationParams): ModelPrediction {
  const vx = params.radius * params.omegaI;
  const flightTime = projectileFlightTime(params.tableHeight, 0, params.gravity);

  return {
    label: "Simple projectile",
    landingDistance: vx * flightTime,
    finalOmega: params.omegaI,
    liftTime: 0,
    liftQ: 0,
    liftX: 0,
    liftY: params.tableHeight + params.radius,
    liftVx: vx,
    liftVy: 0,
    phaseAtLift: "projectile",
  };
}

function predictNoSlipOnly(params: SimulationParams): ModelPrediction {
  const initialNormal = normalPerMass(params, 0, params.omegaI);
  if (initialNormal <= 0) {
    return predictSimple(params);
  }

  let state = [0, params.omegaI];
  let t = 0;
  while (t < MAX_CONTACT_TIME) {
    const fn = normalPerMass(params, state[0], state[1]);
    if (fn <= 0) break;
    state = rk4Step(state, t, INTEGRATION_DT, (s) => [
      s[1],
      (5 / 7) * (params.gravity / params.radius) * Math.sin(s[0]),
    ]);
    t += INTEGRATION_DT;
  }

  const q = clamp(state[0], 0, Math.PI / 2);
  const qDot = Math.max(0, state[1]);
  return makePrediction(params, "No-slip only", t, q, qDot, qDot, "no-slip");
}

function simulateFullContact(params: SimulationParams): {
  prediction: ModelPrediction;
  contactSamples: SimulationSample[];
} {
  const contactSamples: SimulationSample[] = [];
  const baseRotation = params.omegaI * PRE_EDGE_TIME;
  const initialNormal = normalPerMass(params, 0, params.omegaI);

  if (initialNormal <= 0) {
    return {
      prediction: predictSimple(params),
      contactSamples: [
        makeContactSample(params, 0, "projectile", 0, params.omegaI, params.omegaI, baseRotation),
      ],
    };
  }

  let t = 0;
  let lastSampleTime = -Infinity;
  let noSlip = [0, params.omegaI];
  let ratio = 0;

  while (t < MAX_CONTACT_TIME) {
    const q = noSlip[0];
    const qDot = Math.max(0, noSlip[1]);
    const fn = normalPerMass(params, q, qDot);
    const ff = noSlipFrictionPerMass(params, q);
    ratio = safeRatio(ff, fn);

    if (t - lastSampleTime >= SAMPLE_DT || t === 0) {
      contactSamples.push(makeContactSample(params, t, "no-slip", q, qDot, qDot, baseRotation + q));
      lastSampleTime = t;
    }

    if (ratio >= params.muS || fn <= 0) break;

    noSlip = rk4Step(noSlip, t, INTEGRATION_DT, (s) => [
      s[1],
      (5 / 7) * (params.gravity / params.radius) * Math.sin(s[0]),
    ]);
    t += INTEGRATION_DT;
  }

  let q = clamp(noSlip[0], 0, Math.PI / 2);
  let qDot = Math.max(0, noSlip[1]);
  let fn = normalPerMass(params, q, qDot);

  if (fn <= 0) {
    const prediction = makePrediction(params, "Full model", t, q, qDot, qDot, "no-slip");
    contactSamples.push(makeContactSample(params, t, "no-slip", q, qDot, qDot, baseRotation + q));
    return { prediction, contactSamples };
  }

  let slip = [q, qDot, qDot, baseRotation + q];
  while (t < MAX_CONTACT_TIME) {
    q = clamp(slip[0], 0, Math.PI / 2);
    qDot = Math.max(0, slip[1]);
    const spinOmega = Math.max(0, slip[2]);
    fn = normalPerMass(params, q, qDot);

    if (t - lastSampleTime >= SAMPLE_DT) {
      contactSamples.push(makeContactSample(params, t, "slipping", q, qDot, spinOmega, slip[3]));
      lastSampleTime = t;
    }

    if (fn <= 0 || q >= Math.PI / 2) break;

    slip = rk4Step(slip, t, INTEGRATION_DT, (s) => {
      const stateQ = clamp(s[0], 0, Math.PI / 2);
      const stateQDot = Math.max(0, s[1]);
      const stateFn = Math.max(0, normalPerMass(params, stateQ, stateQDot));
      const friction = params.muK * stateFn;
      const qDDot =
        (params.gravity / params.radius) * (Math.sin(stateQ) - params.muK * Math.cos(stateQ)) +
        params.muK * stateQDot * stateQDot;
      const spinDDot = (5 / 2) * (friction / params.radius);
      return [stateQDot, qDDot, spinDDot, Math.max(0, s[2])];
    });
    t += INTEGRATION_DT;
  }

  q = clamp(slip[0], 0, Math.PI / 2);
  qDot = Math.max(0, slip[1]);
  const spinOmega = Math.max(0, slip[2]);
  const prediction = makePrediction(params, "Full model", t, q, qDot, spinOmega, "slipping");
  contactSamples.push(makeContactSample(params, t, "slipping", q, qDot, spinOmega, slip[3]));
  return { prediction, contactSamples };
}

function makePrediction(
  params: SimulationParams,
  label: string,
  liftTime: number,
  q: number,
  qDot: number,
  spinOmega: number,
  phaseAtLift: Phase,
): ModelPrediction {
  const liftX = params.radius * Math.sin(q);
  const liftY = params.tableHeight + params.radius * Math.cos(q);
  const liftVx = params.radius * Math.cos(q) * qDot;
  const liftVy = -params.radius * Math.sin(q) * qDot;
  const drop = Math.max(0.001, liftY - params.radius);
  const flightTime = projectileFlightTime(drop, liftVy, params.gravity);

  return {
    label,
    landingDistance: liftX + liftVx * flightTime,
    finalOmega: spinOmega,
    liftTime,
    liftQ: q,
    liftX,
    liftY,
    liftVx,
    liftVy,
    phaseAtLift,
  };
}

function buildSamples(
  params: SimulationParams,
  contactSamples: SimulationSample[],
  full: ModelPrediction,
): SimulationSample[] {
  const samples: SimulationSample[] = [];
  const v = params.radius * params.omegaI;
  const rollingSteps = Math.max(8, Math.ceil(PRE_EDGE_TIME / 0.02));

  for (let i = 0; i <= rollingSteps; i += 1) {
    const t = (PRE_EDGE_TIME * i) / rollingSteps;
    const x = -v * (PRE_EDGE_TIME - t);
    samples.push({
      t,
      phase: "rolling",
      q: 0,
      edgeAngle: Math.PI / 2,
      angleRate: params.omegaI,
      spinOmega: params.omegaI,
      rotationAngle: params.omegaI * t,
      x,
      y: params.tableHeight + params.radius,
      vx: v,
      vy: 0,
      normalPerMass: params.gravity,
      frictionPerMass: 0,
      frictionRatio: 0,
    });
  }

  contactSamples.forEach((sample) => {
    samples.push({ ...sample, t: sample.t + PRE_EDGE_TIME });
  });

  const projectileStart = full.liftTime + PRE_EDGE_TIME;
  const drop = Math.max(0.001, full.liftY - params.radius);
  const flightTime = projectileFlightTime(drop, full.liftVy, params.gravity);
  const projectileSteps = Math.max(16, Math.ceil(flightTime / PROJECTILE_SAMPLE_DT));
  const startRotation =
    contactSamples.length > 0 ? contactSamples[contactSamples.length - 1].rotationAngle : params.omegaI * PRE_EDGE_TIME;

  for (let i = 1; i <= projectileSteps; i += 1) {
    const tau = (flightTime * i) / projectileSteps;
    const y = full.liftY + full.liftVy * tau - 0.5 * params.gravity * tau * tau;
    samples.push({
      t: projectileStart + tau,
      phase: "projectile",
      q: full.liftQ,
      edgeAngle: Math.PI / 2 - full.liftQ,
      angleRate: 0,
      spinOmega: full.finalOmega,
      rotationAngle: startRotation + full.finalOmega * tau,
      x: full.liftX + full.liftVx * tau,
      y: Math.max(params.radius, y),
      vx: full.liftVx,
      vy: full.liftVy - params.gravity * tau,
      normalPerMass: 0,
      frictionPerMass: 0,
      frictionRatio: 0,
    });
  }

  return samples.sort((a, b) => a.t - b.t);
}

function makeContactSample(
  params: SimulationParams,
  t: number,
  phase: Phase,
  q: number,
  qDot: number,
  spinOmega: number,
  rotationAngle: number,
): SimulationSample {
  const fn = Math.max(0, normalPerMass(params, q, qDot));
  const friction = phase === "slipping" ? params.muK * fn : noSlipFrictionPerMass(params, q);
  return {
    t,
    phase,
    q,
    edgeAngle: Math.PI / 2 - q,
    angleRate: qDot,
    spinOmega,
    rotationAngle,
    x: params.radius * Math.sin(q),
    y: params.tableHeight + params.radius * Math.cos(q),
    vx: params.radius * Math.cos(q) * qDot,
    vy: -params.radius * Math.sin(q) * qDot,
    normalPerMass: fn,
    frictionPerMass: friction,
    frictionRatio: safeRatio(friction, fn),
  };
}

function buildSweep(params: SimulationParams, thresholdOmega: number): SweepPoint[] {
  const maxOmega = Math.max(45, thresholdOmega * 1.55, params.omegaI * 1.15);
  const points = 90;
  const sweep: SweepPoint[] = [];

  for (let i = 0; i <= points; i += 1) {
    const omega = (maxOmega * i) / points;
    const sweptParams = { ...params, omegaI: omega };
    sweep.push({
      omega,
      simple: predictSimple(sweptParams).landingDistance,
      noSlip: predictNoSlipOnly(sweptParams).landingDistance,
      full: simulateFullContact(sweptParams).prediction.landingDistance,
    });
  }

  return sweep;
}

function projectileFlightTime(drop: number, initialVy: number, gravity: number): number {
  return Math.max(0, (initialVy + Math.sqrt(initialVy * initialVy + 2 * gravity * drop)) / gravity);
}

function normalPerMass(params: SimulationParams, q: number, qDot: number): number {
  return params.gravity * Math.cos(q) - params.radius * qDot * qDot;
}

function noSlipFrictionPerMass(params: SimulationParams, q: number): number {
  return (2 / 7) * params.gravity * Math.sin(q);
}

function safeRatio(friction: number, normal: number): number {
  if (normal <= 1e-8) return Number.POSITIVE_INFINITY;
  return Math.abs(friction / normal);
}

function interpolateSample(a: SimulationSample, b: SimulationSample, f: number): SimulationSample {
  const mix = (x: number, y: number) => x + (y - x) * f;
  return {
    t: mix(a.t, b.t),
    phase: f < 0.5 ? a.phase : b.phase,
    q: mix(a.q, b.q),
    edgeAngle: mix(a.edgeAngle, b.edgeAngle),
    angleRate: mix(a.angleRate, b.angleRate),
    spinOmega: mix(a.spinOmega, b.spinOmega),
    rotationAngle: mix(a.rotationAngle, b.rotationAngle),
    x: mix(a.x, b.x),
    y: mix(a.y, b.y),
    vx: mix(a.vx, b.vx),
    vy: mix(a.vy, b.vy),
    normalPerMass: mix(a.normalPerMass, b.normalPerMass),
    frictionPerMass: mix(a.frictionPerMass, b.frictionPerMass),
    frictionRatio: Number.isFinite(a.frictionRatio) && Number.isFinite(b.frictionRatio)
      ? mix(a.frictionRatio, b.frictionRatio)
      : Number.POSITIVE_INFINITY,
  };
}
