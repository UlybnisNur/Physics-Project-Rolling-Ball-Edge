export function TheoryPanel() {
  return (
    <section className="panel theory-panel" aria-labelledby="theory-title">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Theory</p>
          <h2 id="theory-title">Why the textbook model misses the kick</h2>
        </div>
      </div>

      <div className="theory-grid">
        <article>
          <h3>Simple projectile model</h3>
          <p>
            The introductory model treats the ball as if it leaves the table immediately with constant horizontal
            velocity R omega_i and zero vertical velocity. That ignores the short interval where the edge still pushes
            on the ball.
          </p>
        </article>

        <article>
          <h3>No-slip phase</h3>
          <p>
            While the contact point sticks, the center of mass rotates around the table edge. Static friction enforces
            rolling, and the angle satisfies theta_ddot = -(5/7)(g/R) cos(theta).
          </p>
        </article>

        <article>
          <h3>Slipping phase</h3>
          <p>
            Static friction cannot stay finite all the way to lift-off because F_f/F_N grows as the normal force
            becomes small. The ball must slip before it leaves, so kinetic friction and a separate center angle alpha
            are included.
          </p>
        </article>

        <article>
          <h3>Lift-off condition</h3>
          <p>
            Contact ends when F_N = 0. At that instant the edge can no longer constrain the center of mass, so the
            remaining motion is projectile motion with the velocity produced by the contact phase.
          </p>
        </article>
      </div>

      <div className="equation-strip" aria-label="Core equations">
        <code>F_N/m = -R theta_dot^2 + g sin(theta)</code>
        <code>F_f/m = R theta_ddot + g cos(theta)</code>
        <code>theta_ddot = -(5/7)(g/R) cos(theta)</code>
        <code>alpha_ddot = -(g/R)(cos(alpha) - mu_k sin(alpha)) - mu_k alpha_dot^2</code>
      </div>
    </section>
  );
}
