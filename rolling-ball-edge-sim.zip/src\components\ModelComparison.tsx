import { Gauge, Zap } from "lucide-react";
import type { SimulationResult, SimulationSample } from "../utils/physics";
import { formatNumber } from "../utils/physics";

interface ModelComparisonProps {
  result: SimulationResult;
  current: SimulationSample;
}

export function ModelComparison({ result, current }: ModelComparisonProps) {
  const kickDelta = result.full.landingDistance - result.simple.landingDistance;
  const ratio = Number.isFinite(current.frictionRatio) ? formatNumber(current.frictionRatio, 2) : "infinite";
  const edgeAngleDegrees = (current.edgeAngle * 180) / Math.PI;

  const rows = [
    result.simple,
    result.noSlipOnly,
    result.full,
  ];

  return (
    <section className="panel comparison-panel" aria-labelledby="comparison-title">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Live state</p>
          <h2 id="comparison-title">Model comparison</h2>
        </div>
        <div className={`kick-badge ${result.kickObserved ? "active" : ""}`}>
          <Zap size={16} />
          <span>{result.kickObserved ? "Kick observed." : "No significant kick."}</span>
        </div>
      </div>

      <div className="metrics-grid">
        <Metric label="Current phase" value={current.phase} />
        <Metric label="theta/alpha" value={`${formatNumber(edgeAngleDegrees, 1)} deg`} />
        <Metric label="Angular velocity" value={`${formatNumber(current.spinOmega, 2)} rad/s`} />
        <Metric label="F_N / m" value={`${formatNumber(current.normalPerMass, 2)} m/s^2`} />
        <Metric label="F_f / m" value={`${formatNumber(current.frictionPerMass, 2)} m/s^2`} />
        <Metric label="F_f / F_N" value={ratio} />
        <Metric label="omega_f" value={`${formatNumber(result.full.finalOmega, 2)} rad/s`} />
        <Metric label="Full landing distance" value={`${formatNumber(result.full.landingDistance, 3)} m`} />
      </div>

      <div className="model-table" role="table" aria-label="Predicted landing distance comparison">
        <div className="model-row header" role="row">
          <span>Model</span>
          <span>Distance</span>
          <span>omega_f</span>
        </div>
        {rows.map((row) => (
          <div className="model-row" role="row" key={row.label}>
            <span>{row.label}</span>
            <span>{formatNumber(row.landingDistance, 3)} m</span>
            <span>{formatNumber(row.finalOmega, 2)} rad/s</span>
          </div>
        ))}
      </div>

      <div className="threshold-card">
        <Gauge size={18} />
        <p>
          Kick cutoff marker: omega_i near sqrt(g/R) = {formatNumber(result.thresholdOmega, 2)} rad/s.
          For Bacon's 2.5 cm diameter steel ball this is about 28 rad/s.
        </p>
      </div>
      <p className="small-note">
        Full model minus simple projectile: {formatNumber(kickDelta, 3)} m.
      </p>
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
