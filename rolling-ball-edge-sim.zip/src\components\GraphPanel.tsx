import type { SimulationResult } from "../utils/physics";

interface GraphPanelProps {
  result: SimulationResult;
}

interface Point {
  x: number;
  y: number;
}

interface Series {
  label: string;
  color: string;
  points: Point[];
  dashed?: boolean;
}

interface Marker {
  x: number;
  label: string;
  color: string;
}

export function GraphPanel({ result }: GraphPanelProps) {
  const timePoints = result.samples.map((sample) => ({
    time: sample.t - result.edgeTime,
    angle: (sample.edgeAngle * 180) / Math.PI,
    omega: sample.spinOmega,
    normal: sample.normalPerMass,
  }));

  return (
    <section className="graph-section" aria-labelledby="graphs-title">
      <div className="section-heading">
        <p className="eyebrow">Numerical output</p>
        <h2 id="graphs-title">Graphs</h2>
      </div>

      <div className="graph-grid">
        <LineChart
          title="Angle vs time"
          xLabel="time from edge (s)"
          yLabel="theta or alpha (deg)"
          series={[
            {
              label: "edge angle",
              color: "#2563eb",
              points: timePoints.map((point) => ({ x: point.time, y: point.angle })),
            },
          ]}
          markers={[{ x: 0, label: "edge", color: "#111827" }]}
        />

        <LineChart
          title="Angular velocity vs time"
          xLabel="time from edge (s)"
          yLabel="omega (rad/s)"
          series={[
            {
              label: "spin omega",
              color: "#0f766e",
              points: timePoints.map((point) => ({ x: point.time, y: point.omega })),
            },
          ]}
          markers={[{ x: 0, label: "edge", color: "#111827" }]}
        />

        <LineChart
          title="Normal force per mass vs time"
          xLabel="time from edge (s)"
          yLabel="F_N / m (m/s^2)"
          series={[
            {
              label: "normal force",
              color: "#b45309",
              points: timePoints.map((point) => ({ x: point.time, y: point.normal })),
            },
          ]}
          markers={[{ x: 0, label: "edge", color: "#111827" }]}
        />

        <LineChart
          title="Landing distance vs initial angular velocity"
          xLabel="omega_i (rad/s)"
          yLabel="landing distance (m)"
          series={[
            {
              label: "simple",
              color: "#64748b",
              dashed: true,
              points: result.sweep.map((point) => ({ x: point.omega, y: point.simple })),
            },
            {
              label: "no-slip only",
              color: "#7c3aed",
              dashed: true,
              points: result.sweep.map((point) => ({ x: point.omega, y: point.noSlip })),
            },
            {
              label: "full model",
              color: "#dc2626",
              points: result.sweep.map((point) => ({ x: point.omega, y: point.full })),
            },
          ]}
          markers={[
            { x: result.thresholdOmega, label: "sqrt(g/R)", color: "#ea580c" },
            { x: result.params.omegaI, label: "current", color: "#111827" },
          ]}
        />
      </div>
    </section>
  );
}

function LineChart({
  title,
  xLabel,
  yLabel,
  series,
  markers = [],
}: {
  title: string;
  xLabel: string;
  yLabel: string;
  series: Series[];
  markers?: Marker[];
}) {
  const width = 560;
  const height = 310;
  const margin = { top: 28, right: 24, bottom: 52, left: 58 };
  const allPoints = series.flatMap((line) => line.points).filter((point) => Number.isFinite(point.x) && Number.isFinite(point.y));
  const xMin = Math.min(...allPoints.map((point) => point.x));
  const xMax = Math.max(...allPoints.map((point) => point.x));
  const rawYMin = Math.min(...allPoints.map((point) => point.y));
  const rawYMax = Math.max(...allPoints.map((point) => point.y));
  const yPad = Math.max(0.05, (rawYMax - rawYMin) * 0.12);
  const yMin = rawYMin - yPad;
  const yMax = rawYMax + yPad;
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;
  const sx = (x: number) => margin.left + ((x - xMin) / Math.max(1e-9, xMax - xMin)) * plotWidth;
  const sy = (y: number) => margin.top + (1 - (y - yMin) / Math.max(1e-9, yMax - yMin)) * plotHeight;

  return (
    <article className="chart-card">
      <h3>{title}</h3>
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={title}>
        <rect className="chart-bg" x={margin.left} y={margin.top} width={plotWidth} height={plotHeight} />
        {ticks(5).map((tick) => {
          const y = margin.top + tick * plotHeight;
          const value = yMax - tick * (yMax - yMin);
          return (
            <g key={`y-${tick}`}>
              <line className="grid-line" x1={margin.left} x2={width - margin.right} y1={y} y2={y} />
              <text className="axis-label" x={margin.left - 10} y={y + 4} textAnchor="end">
                {formatTick(value)}
              </text>
            </g>
          );
        })}
        {ticks(5).map((tick) => {
          const x = margin.left + tick * plotWidth;
          const value = xMin + tick * (xMax - xMin);
          return (
            <g key={`x-${tick}`}>
              <line className="grid-line" x1={x} x2={x} y1={margin.top} y2={height - margin.bottom} />
              <text className="axis-label" x={x} y={height - margin.bottom + 20} textAnchor="middle">
                {formatTick(value)}
              </text>
            </g>
          );
        })}
        <line className="axis-line" x1={margin.left} x2={width - margin.right} y1={height - margin.bottom} y2={height - margin.bottom} />
        <line className="axis-line" x1={margin.left} x2={margin.left} y1={margin.top} y2={height - margin.bottom} />

        {markers
          .filter((marker) => marker.x >= xMin && marker.x <= xMax)
          .map((marker) => {
            const x = sx(marker.x);
            return (
              <g key={`${marker.label}-${marker.x}`}>
                <line className="marker-line" x1={x} x2={x} y1={margin.top} y2={height - margin.bottom} stroke={marker.color} />
                <text className="marker-label" x={x + 5} y={margin.top + 14} fill={marker.color}>
                  {marker.label}
                </text>
              </g>
            );
          })}

        {series.map((line) => (
          <path
            key={line.label}
            d={pathFor(line.points, sx, sy)}
            fill="none"
            stroke={line.color}
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={line.dashed ? "7 6" : undefined}
          />
        ))}

        <text className="chart-axis-title" x={width / 2} y={height - 12} textAnchor="middle">
          {xLabel}
        </text>
        <text className="chart-axis-title vertical" x={16} y={height / 2} textAnchor="middle" transform={`rotate(-90 16 ${height / 2})`}>
          {yLabel}
        </text>
      </svg>
      <div className="legend">
        {series.map((line) => (
          <span key={line.label}>
            <i style={{ background: line.color }} />
            {line.label}
          </span>
        ))}
      </div>
    </article>
  );
}

function pathFor(points: Point[], sx: (x: number) => number, sy: (y: number) => number): string {
  return points
    .filter((point) => Number.isFinite(point.x) && Number.isFinite(point.y))
    .map((point, index) => `${index === 0 ? "M" : "L"} ${sx(point.x).toFixed(2)} ${sy(point.y).toFixed(2)}`)
    .join(" ");
}

function ticks(count: number): number[] {
  return Array.from({ length: count }, (_, index) => index / (count - 1));
}

function formatTick(value: number): string {
  if (Math.abs(value) >= 100) return value.toFixed(0);
  if (Math.abs(value) >= 10) return value.toFixed(1);
  return value.toFixed(2);
}
