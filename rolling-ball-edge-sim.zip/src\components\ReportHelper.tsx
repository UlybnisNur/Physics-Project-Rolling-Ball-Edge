import { Clipboard, Download } from "lucide-react";
import type { SimulationParams, SimulationResult } from "../utils/physics";
import { formatNumber } from "../utils/physics";

interface ReportHelperProps {
  params: SimulationParams;
  result: SimulationResult;
}

export function ReportHelper({ params, result }: ReportHelperProps) {
  const report = buildReport(params, result);

  const copyReport = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(report);
      }
    } catch {
      // Clipboard access depends on browser permissions and secure context.
    }
  };

  const downloadReport = () => {
    const blob = new Blob([report], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "rolling-ball-summary.txt";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="panel report-panel" aria-labelledby="report-title">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Report helper</p>
          <h2 id="report-title">Summary and error sources</h2>
        </div>
        <div className="playback-row">
          <button className="icon-button" type="button" onClick={copyReport} aria-label="Copy report summary">
            <Clipboard size={18} />
          </button>
          <button className="icon-button" type="button" onClick={downloadReport} aria-label="Download report summary">
            <Download size={18} />
          </button>
        </div>
      </div>

      <textarea className="report-text" readOnly value={report} />
    </section>
  );
}

function buildReport(params: SimulationParams, result: SimulationResult): string {
  const kickText = result.kickObserved ? "A kick is observed" : "No significant kick is observed";
  return [
    "Simulation summary",
    "",
    `The simulation models a ball of radius R = ${formatNumber(params.radius, 4)} m rolling off a table of height ${formatNumber(
      params.tableHeight,
      2,
    )} m with initial angular velocity omega_i = ${formatNumber(params.omegaI, 2)} rad/s.`,
    `The full Bacon-style model uses an initial no-slip phase, switches to slipping when F_f/F_N reaches mu_s = ${formatNumber(
      params.muS,
      2,
    )}, and ends contact when F_N = 0. Kinetic friction is set to mu_k = ${formatNumber(params.muK, 2)}.`,
    `${kickText}: the full model predicts a landing distance of ${formatNumber(
      result.full.landingDistance,
      3,
    )} m, compared with ${formatNumber(result.simple.landingDistance, 3)} m for the simple projectile model.`,
    `The final angular velocity after lift-off is omega_f = ${formatNumber(result.full.finalOmega, 2)} rad/s.`,
    "",
    "Possible sources of experimental error",
    "- Measurement uncertainty in angle, distance, and table height.",
    "- Video frame rate and motion blur.",
    "- Imperfect ball alignment before release.",
    "- Friction variation across the surface and edge.",
    "- Table edge shape, roughness, or rounding.",
    "- Uncertainty in static and kinetic friction coefficients.",
  ].join("\n");
}
