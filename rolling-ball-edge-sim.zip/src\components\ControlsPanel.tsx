import { Pause, Play, RotateCcw } from "lucide-react";
import type { SimulationParams } from "../utils/physics";
import { DEFAULT_PARAMS } from "../utils/physics";

interface ControlsPanelProps {
  params: SimulationParams;
  playing: boolean;
  onChange: (params: SimulationParams) => void;
  onTogglePlaying: () => void;
  onResetAnimation: () => void;
}

interface SliderSpec {
  key: keyof SimulationParams;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  decimals: number;
}

const SLIDERS: SliderSpec[] = [
  { key: "omegaI", label: "Initial angular velocity omega_i", unit: "rad/s", min: 0, max: 55, step: 0.05, decimals: 2 },
  { key: "radius", label: "Ball radius R", unit: "m", min: 0.005, max: 0.05, step: 0.0005, decimals: 4 },
  { key: "muS", label: "Static friction coefficient mu_s", unit: "", min: 0.02, max: 1.1, step: 0.01, decimals: 2 },
  { key: "muK", label: "Kinetic friction coefficient mu_k", unit: "", min: 0, max: 0.9, step: 0.01, decimals: 2 },
  { key: "tableHeight", label: "Table height", unit: "m", min: 0.25, max: 1.6, step: 0.01, decimals: 2 },
  { key: "gravity", label: "Gravity g", unit: "m/s^2", min: 1.62, max: 12, step: 0.01, decimals: 2 },
  { key: "speed", label: "Simulation speed", unit: "x", min: 0.25, max: 4, step: 0.05, decimals: 2 },
];

export function ControlsPanel({
  params,
  playing,
  onChange,
  onTogglePlaying,
  onResetAnimation,
}: ControlsPanelProps) {
  const updateParam = (key: keyof SimulationParams, value: number) => {
    onChange({ ...params, [key]: value });
  };

  const resetParams = () => {
    onChange(DEFAULT_PARAMS);
    onResetAnimation();
  };

  return (
    <section className="panel controls-panel" aria-labelledby="controls-title">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Interactive model</p>
          <h2 id="controls-title">Controls</h2>
        </div>
        <div className="playback-row">
          <button className="icon-button primary" type="button" onClick={onTogglePlaying} aria-label={playing ? "Pause" : "Play"}>
            {playing ? <Pause size={18} /> : <Play size={18} />}
          </button>
          <button className="icon-button" type="button" onClick={onResetAnimation} aria-label="Restart animation">
            <RotateCcw size={18} />
          </button>
        </div>
      </div>

      <div className="control-stack">
        {SLIDERS.map((slider) => (
          <label className="control" key={slider.key}>
            <span className="control-label">
              <span>{slider.label}</span>
              <output>
                {params[slider.key].toFixed(slider.decimals)}
                {slider.unit ? ` ${slider.unit}` : ""}
              </output>
            </span>
            <input
              type="range"
              min={slider.min}
              max={slider.max}
              step={slider.step}
              value={params[slider.key]}
              onChange={(event) => updateParam(slider.key, Number(event.target.value))}
            />
          </label>
        ))}
      </div>

      <button className="text-button" type="button" onClick={resetParams}>
        Reset model values
      </button>
    </section>
  );
}
