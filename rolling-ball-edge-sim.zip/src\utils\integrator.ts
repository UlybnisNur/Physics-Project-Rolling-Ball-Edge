export type Derivative = (state: number[], t: number) => number[];

export function rk4Step(state: number[], t: number, dt: number, derivative: Derivative): number[] {
  const k1 = derivative(state, t);
  const k2 = derivative(addScaled(state, k1, dt / 2), t + dt / 2);
  const k3 = derivative(addScaled(state, k2, dt / 2), t + dt / 2);
  const k4 = derivative(addScaled(state, k3, dt), t + dt);

  return state.map((value, index) => {
    return value + (dt / 6) * (k1[index] + 2 * k2[index] + 2 * k3[index] + k4[index]);
  });
}

function addScaled(state: number[], derivative: number[], scale: number): number[] {
  return state.map((value, index) => value + derivative[index] * scale);
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
